# notes/urls.py
from django.urls import path
from .views import (
    note_list,
    note_detail,
    note_create,
    note_edit,
    note_delete
)

urlpatterns = [
    # URL for displaying all the notes at once
    path('', note_list, name='note_list'),

    # URL for displaying details of a sticky note
    path('note/<int:pk>/', note_detail, name='note_detail'),

    # URL for creating a new sticky note
    path('note/new/', note_create, name='note_create'),

    # URL for editing / updating an existing note
    path('note/<int:pk>/edit/', note_edit, name='note_edit'),

    # URL for deleting an existing sticky note
    path('note/<int:pk>/delete/', note_delete, name='note_delete'),
]
