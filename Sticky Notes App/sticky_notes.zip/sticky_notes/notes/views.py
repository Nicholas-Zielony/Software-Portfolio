# notes/views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Note
from .forms import NoteForm


# Create your views here.
def note_list(request):
    """
    Retrieves all notes from the database
    and displays them in a grid.
    """
    notes = Note.objects.all().order_by('id')
    return render(request, 'notes/index.html', {'notes': notes})


def note_detail(request, pk):
    """
    Displays the full content of a specific note
    identified by its primary key.
    """
    note = get_object_or_404(Note, pk=pk)
    return render(request, 'notes/detail.html', {'note': note})


def note_create(request):
    """
    Handles the creation of a new note via a
    POST request or displays an empty form.
    """
    if request.method == "POST":
        form = NoteForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect('note_list')
    else:
        form = NoteForm()
    return render(request, 'notes/form.html',
                  {'form': form, 'heading': 'Create Sticky Note'})


def note_edit(request, pk):
    """
    Handles updating an existing note.
    Prevents editing if the note is an admin note.
    """
    note = get_object_or_404(Note, pk=pk)

    if note.is_admin_note():
        return redirect('note_detail', pk=pk)

    if request.method == "POST":
        form = NoteForm(request.POST, instance=note)
        if form.is_valid():
            form.save()
            return redirect('note_detail', pk=pk)
    else:
        form = NoteForm(instance=note)
    return render(request, 'notes/form.html',
                  {'form': form, 'heading': 'Update Sticky Note'})


def note_delete(request, pk):
    """
    Deletes a specific note.
    Prevents deletion if the note is an admin note.
    """
    note = get_object_or_404(Note, pk=pk)
    
    if not note.is_admin_note():
        note.delete()
        
    return redirect('note_list')
