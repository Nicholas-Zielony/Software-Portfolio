from django.test import TestCase
from django.urls import reverse
from .models import Note, Author


class NoteTests(TestCase):
    def setUp(self):
        self.author = Author.objects.create(name='Test Author')
        self.note = Note.objects.create(
            title='Test Note', body='Test Body', author=self.author
        )

    def test_create_note(self):
        """A note can be created with the expected values."""
        note = Note.objects.create(
            title='New Note', body='New Body', author=self.author
        )
        self.assertEqual(note.title, 'New Note')
        self.assertEqual(note.body, 'New Body')
        self.assertEqual(Note.objects.count(), 2)

    def test_note_views(self):
        """List and detail pages display saved note data."""
        list_response = self.client.get(reverse('note_list'))
        detail_response = self.client.get(
            reverse('note_detail', args=[self.note.id])
        )
        self.assertContains(list_response, 'Test Author')
        self.assertContains(detail_response, 'Test Note')
        self.assertContains(detail_response, 'Test Body')

    def test_update_note(self):
        """A normal note can be updated."""
        self.client.post(reverse('note_edit', args=[self.note.id]), {
            'title': 'Updated Note',
            'body': 'Updated Body',
            'author': self.author.id,
        })
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, 'Updated Note')
        self.assertEqual(self.note.body, 'Updated Body')

    def test_delete_note(self):
        """A normal note can be deleted."""
        self.client.post(reverse('note_delete', args=[self.note.id]))
        self.assertFalse(Note.objects.filter(id=self.note.id).exists())

    def test_admin_note_cannot_be_updated(self):
        """A note authored by admin cannot be updated."""
        admin = Author.objects.create(name='admin')
        note = Note.objects.create(
            title='Admin Note', body='Protected', author=admin
        )
        self.client.post(reverse('note_edit', args=[note.id]), {
            'title': 'Changed', 'body': 'Changed', 'author': admin.id,
        })
        note.refresh_from_db()
        self.assertEqual(note.title, 'Admin Note')
        self.assertEqual(note.body, 'Protected')

    def test_admin_note_cannot_be_deleted(self):
        """A note authored by admin cannot be deleted."""
        admin = Author.objects.create(name='Admin')
        note = Note.objects.create(
            title='Admin Note', body='Protected', author=admin
        )
        self.client.post(reverse('note_delete', args=[note.id]))
        self.assertTrue(Note.objects.filter(id=note.id).exists())

    def test_admin_note_hides_edit_and_delete(self):
        """Admin note detail pages do not show edit or delete controls."""
        admin = Author.objects.create(name='ADMIN')
        note = Note.objects.create(
            title='Admin Note', body='Protected', author=admin
        )
        response = self.client.get(reverse('note_detail', args=[note.id]))
        self.assertNotContains(response, '>Edit<', html=False)
        self.assertNotContains(response, '>Delete<', html=False)
        self.assertContains(response, 'protected admin note')
