# notes/tests.py
from django.test import TestCase
from django.urls import reverse
from .models import Note, Author


class NoteCreateTest(TestCase):
    def setUp(self):
        # Initialize the sample note.
        author = Author.objects.create(name='Test Author')
        Note.objects.create(
            title="Test Note",
            body="Test Body",
            author=author
        )

    def test_create_note(self):
        # Create a new note to test with.
        author = Author.objects.create(name='Test Author 2')
        Note.objects.create(
            title="Test Note 2",
            body="Test Body 2",
            author=author
        )

        # Verify that original note has the expected data.
        note = Note.objects.get(id=1)
        self.assertEqual(note.title, 'Test Note')
        self.assertEqual(note.body, 'Test Body')
        self.assertEqual(note.author.name, 'Test Author')

        # Verify that new note has the expected data.
        note = Note.objects.get(id=2)
        self.assertEqual(note.title, 'Test Note 2')
        self.assertEqual(note.body, 'Test Body 2')
        self.assertEqual(note.author.name, 'Test Author 2')

        # Check that there were 2 objects created
        self.assertEqual(Note.objects.count(), 2)


class NoteViewTest(TestCase):
    def setUp(self):
        # Initialize the sample note.
        author = Author.objects.create(name='Test Author')
        Note.objects.create(
            title="Test Note",
            body="Test Body",
            author=author
        )

    def test_post_list_view(self):
        # Test the note_list view
        response = self.client.get(reverse('note_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Author')

    def test_post_detail_view(self):
        # Test the note_detail view
        note = Note.objects.get(id=1)
        response = self.client.get(
            reverse('note_detail', args=[str(note.id)]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')
        self.assertContains(response, 'Test Body')


class NoteDeleteTest(TestCase):
    def setUp(self):
        # Initialize the sample note.
        author = Author.objects.create(name='Test Author')
        Note.objects.create(
            title="Test Note",
            body="Test Body",
            author=author
        )

    def test_delete_note(self):
        # Setup note for deletion
        author = Author.objects.create(name='Delete Author')
        note = Note.objects.create(
            title="Delete Note",
            body="Delete Body",
            author=author
        )
        # Verify that a standard note can be deleted.
        self.client.post(reverse('note_delete', args=[note.id]))
        # Check that there is 1 note left (Init note)
        self.assertEqual(Note.objects.count(), 1)


class NoteAdminProtectionTest(TestCase):
    def setUp(self):
        # Initialize the test client and a sample note.
        author = Author.objects.create(name='Test Author')
        Note.objects.create(
            title="Test Note",
            body="Test Body",
            author=author
        )

    def test_admin_note_protection(self):
        # Verify that a note authored by 'admin' cannot be deleted.
        author = Author.objects.create(name="admin")
        admin_note = Note.objects.create(
            title="Admin Note",
            body="Secret... :0",
            author=author
        )
        self.client.post(reverse('note_delete', args=[admin_note.id]))

        # Count should still be 2 (original test note + protected admin note)
        self.assertTrue(Note.objects.filter(id=admin_note.id).exists())
        self.assertEqual(Note.objects.count(), 2)
