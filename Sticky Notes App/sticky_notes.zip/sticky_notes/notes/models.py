from django.db import models


# Create your models here.
class Note(models.Model):
    """
    Represents a single sticky note in the system.

    Fields:
    - title: CharField for the note title with a
    maximum length of 100 characters.
    - body: TextField for the note content.
    - created: DateField set to the current date when the note is created.

    Relationships:
    - author: ForeignKey representing the author of the sticky note.

    Methods:
    - is_admin_note: Checks if the author of a note is
    an admin. Returns True or False.
    - __str__: Returns a string representation of the
    note, showing the title.

    :param models.Model: Django's base model class.
    """
    title = models.CharField(max_length=100)
    body = models.TextField()
    created = models.DateField(auto_now_add=True)

    # ForeignKey definition for author's relationship.
    # For deleting any notes that a deleted author has made.
    author = models.ForeignKey(
        "Author",
        on_delete=models.CASCADE,
        null=True, blank=True
    )

    def is_admin_note(self):
        """
        Checks if the note was authored by an admin.
        Admin notes are protected from editing and deletion.

        Also protects against the "is None" type.
        """
        if self.author is not None:
            if self.author.name.lower() == "admin":
                return True
        return False

    def __str__(self):
        return self.title


class Author(models.Model):
    """
    Represents the author of a sticky note message.

    Fields:
    - name: CharField for the author's name.
     Methods:
    - __str__: Returns a string representation
    of the author, showing the name.

    :param models.Model: Django's base model class.
    """

    name = models.CharField(max_length=64)

    def __str__(self):
        return self.name
