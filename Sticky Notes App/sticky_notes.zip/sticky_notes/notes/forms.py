# notes/forms.py
from django import forms
from .models import Note


class NoteForm(forms.ModelForm):
    """
    A form for creating and updating Note object instances.

    Fields:
    - title: CharField for the note title.
    - body: TextField for the note content.

    Meta class:
    - Defines the model to use (Note) and the fields to include in the form.

    :param forms.ModelForm: Django's ModelForm class.

    """
    class Meta:
        model = Note
        fields = ['title', 'body', 'author']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-input',
                                            'placeholder': 'Note Title'}),
            'body': forms.Textarea(
                attrs={'class': 'form-input',
                       'placeholder': 'Write your note here...',
                       'rows': 5}
                       ),
        }
